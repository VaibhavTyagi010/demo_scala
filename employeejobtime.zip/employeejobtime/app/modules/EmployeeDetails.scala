package modules



case class EmployeeDetails(employeeId:Long,Name:String,comingTime:String,goingTime:String)
