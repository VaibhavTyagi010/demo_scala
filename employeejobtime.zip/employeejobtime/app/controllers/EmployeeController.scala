package controllers


import com.google.inject.Inject
import modules.EmployeeDetails
import play.api.Configuration
import play.api.mvc.{Action, AnyContent, BaseController, ControllerComponents}
import scala.collection.mutable
import play.api.libs.json._




class EmployeeController @Inject()(val controllerComponents: ControllerComponents) extends BaseController {


  val employee = new mutable.ListBuffer[EmployeeDetails]()
  employee += EmployeeDetails(1, "test1", "9:20", "6:20")
  employee += EmployeeDetails(2, "test2", "9:20", "6:20")

  implicit val EmployeeDetailJson = Json.format[EmployeeDetails]


  def getAll(): Action[AnyContent] = Action {
    if (employee.isEmpty) {
      NoContent
    } else {
      Ok(Json.toJson(employee))
    }
  }

  def getById(Id:Long):Action[AnyContent]=Action
  {
    val foundItem =employee.find(_.employeeId==Id)
    foundItem match {
      case Some(item) => Ok(Json.toJson(item))
      case None => NotFound
    }
  }




  def addNewEmployee()=Action(parse.json) {
    implicit request =>

      var contant=request.body
      contant.validate[Seq[EmployeeDetails]] match {
        case JsSuccess(value: Seq[EmployeeDetails], path) => ???
        case JsError(errors) => ???
      }

      

      }
}



